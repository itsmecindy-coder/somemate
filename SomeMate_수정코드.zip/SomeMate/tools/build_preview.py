from pathlib import Path
import base64
root=Path(__file__).resolve().parents[1]
domain=(root/'domain.js').read_text(encoding='utf-8').replace('export ','')
hero='data:image/png;base64,'+base64.b64encode((root/'assets/hero.png').read_bytes()).decode()
html=(root/'tools/preview.template.html').read_text(encoding='utf-8').replace('/* DOMAIN */',domain).replace('/* HERO */',hero)
(root/'SomeMate_preview.html').write_text(html,encoding='utf-8')
