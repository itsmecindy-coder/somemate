from PIL import Image, ImageDraw
from pathlib import Path
p=Path('SomeMate/assets');p.mkdir(parents=True,exist_ok=True)
im=Image.new('RGBA',(780,570),(255,252,249,0));d=ImageDraw.Draw(im)
d.ellipse((155,42,625,512),fill='#FBE9E2')
d.ellipse((185,460,604,503),fill='#EED9D2')
d.rounded_rectangle((100,116,464,323),radius=65,fill='#CA554B')
d.polygon([(169,302),(151,371),(238,316)],fill='#CA554B')
d.rounded_rectangle((348,267,687,457),radius=65,fill='#DCD0E8')
d.polygon([(566,444),(642,490),(617,421)],fill='#DCD0E8')
d.ellipse((204,157,289,244),fill='#FFF9F5');d.ellipse((275,157,360,244),fill='#FFF9F5')
d.polygon([(207,203),(357,203),(282,284)],fill='#FFF9F5')
for x in [419,489,559]:d.ellipse((x,343,x+22,365),fill='#957BAA')
for x,y,r in [(639,158,12),(127,427,8),(378,68,8)]:
 d.line((x-r,y,x+r,y),fill='#DDAA72',width=5);d.line((x,y-r,x,y+r),fill='#DDAA72',width=5)
im.save(p/'hero.png')

