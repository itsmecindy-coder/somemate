import React,{useState,useEffect,useRef} from 'react';
import {View,Text,TextInput,Pressable,ScrollView,Modal,Image,StyleSheet,KeyboardAvoidingView,Platform,Alert,StatusBar} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import Calendar from './Calendar';
import {mates,relations,empty,validate,elapsed,greeting,demoReplies} from './domain';
const KEY='somemate.rooms.v2';
const Hero=()=> <Image source={require('./assets/hero.png')} style={{width:260,height:190,alignSelf:'center'}} resizeMode="contain"/>;
function Button({title,onPress,light}){return <Pressable accessibilityRole="button" style={[s.button,light&&s.light]} onPress={onPress}><Text style={{fontWeight:'700',color:light?'#CA554B':'white'}}>{title}</Text></Pressable>}
export default function App(){
const [screen,setScreen]=useState('login'),[rooms,setRooms]=useState([]),[ready,setReady]=useState(false),[active,setActive]=useState(null),[form,setForm]=useState(null),[error,setError]=useState(''),[search,setSearch]=useState(''),[text,setText]=useState(''),[photo,setPhoto]=useState(null),[notify,setNotify]=useState(false),[passwordVisible,setPasswordVisible]=useState(false);
const [calendar,setCalendar]=useState(false);
const scroll=useRef(null),room=rooms.find(r=>r.id===active);
useEffect(()=>{AsyncStorage.getItem(KEY).then(v=>{if(v)setRooms(JSON.parse(v))}).catch(()=>Alert.alert('기록 불러오기 실패')).finally(()=>setReady(true))},[]);
useEffect(()=>{if(ready)AsyncStorage.setItem(KEY,JSON.stringify(rooms)).catch(()=>Alert.alert('저장 실패','기기 저장 공간을 확인해 줘.'))},[rooms,ready]);
function newRoom(){setError('');setForm({...empty})}
function save(){const e=validate(form);if(e){setError(e);return}const id=String(Date.now());setRooms(rs=>[{id,partner:{...form,name:form.name.trim()},messages:greeting()},...rs]);setActive(id);setForm(null);setScreen('chat')}
async function pick(){try{const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],quality:0.7});if(!result.canceled)setPhoto(result.assets[0].uri)}catch{Alert.alert('사진 선택 실패','사진 접근 권한을 확인해 줘.')}}
function send(){if(!room||(!text.trim()&&!photo))return;setRooms(rs=>rs.map(r=>r.id===active?{...r,messages:[...r.messages,{id:String(Date.now()),user:true,text:text.trim(),image:photo},...demoReplies()]}:r));setText('');setPhoto(null)}
const stub=label=>Alert.alert(label,'실제 인증 서비스 연동이 필요한 기능이야.');
if(!ready)return <View style={s.root}><Text>상담 기록 불러오는 중…</Text></View>;
return <KeyboardAvoidingView style={s.root} behavior={Platform.OS==='ios'?'padding':undefined}><StatusBar barStyle="dark-content"/>
<View style={s.top}><Text style={s.small}>SomeMate · UI 체험</Text><Pressable onPress={()=>setNotify(true)}><Text style={s.small}>알림 예시 ♡</Text></Pressable></View>
{screen==='login'?<ScrollView contentContainerStyle={s.login} keyboardShouldPersistTaps="handled">
<Text style={s.logo}>SomeMate</Text><Text style={s.centerSmall}>혼자 읽기 어려운 마음, 함께 읽어볼까?</Text><Hero/>
<Text style={[s.heading,{textAlign:'center'}]}>네 이야기를 들려줘.</Text>
<TextInput style={s.input} accessibilityLabel="아이디" placeholder="아이디" autoCapitalize="none"/>
<View style={s.row}><TextInput style={[s.input,{flex:1}]} accessibilityLabel="비밀번호" placeholder="비밀번호" secureTextEntry={!passwordVisible}/><Pressable accessibilityLabel="비밀번호 표시 전환" onPress={()=>setPasswordVisible(!passwordVisible)}><Text> 👁 </Text></Pressable></View>
<Button title="로그인 화면 체험" onPress={()=>{setScreen('list');if(!rooms.length)newRoom()}}/>
<View style={s.spread}>{['회원가입','아이디 / 비밀번호 찾기'].map(x=><Pressable key={x} onPress={()=>stub(x)}><Text style={s.small}>{x}</Text></Pressable>)}</View>
<Text style={s.centerSmall}>간편하게 시작하기</Text><View style={s.spread}>{['카카오','Google','Apple'].map(x=><Button key={x} title={x} light onPress={()=>stub(x+' 로그인')}/>)}</View>
<Text style={s.centerSmall}>마음을 나누는 작은 아지트, 썸메이트</Text>
</ScrollView>:screen==='list'?<>
<View style={s.header}><Text style={s.title}>내 상담</Text><Pressable accessibilityLabel="새 상담" onPress={newRoom}><Text style={s.title}>＋</Text></Pressable></View>
<Text style={s.subtitle}>오늘은 누구의 마음이 궁금해?</Text><TextInput style={[s.input,{margin:20}]} placeholder="상대 이름으로 검색" value={search} onChangeText={setSearch}/>
<ScrollView contentContainerStyle={{padding:20}}>{!rooms.length?<View style={s.empty}><Hero/><Text style={s.heading}>아직 나눈 이야기가 없어요</Text><Text style={s.centerSmall}>마음 쓰이는 사람이 있다면, 우리에게 편하게 털어놔.</Text></View>:rooms.filter(r=>r.partner.name.includes(search)).map(r=><Pressable key={r.id} style={s.card} onPress={()=>{setActive(r.id);setScreen('chat')}}><Text style={s.heading}>{r.partner.name}   ›</Text><Text style={s.small}>{r.partner.relation} {r.partner.date?'· 연락 '+elapsed(r.partner.date)+'일째':''}</Text><Text style={s.small} numberOfLines={1}>{r.messages.at(-1)?.text}</Text></Pressable>)}</ScrollView>
<View style={s.footer}><Button title="새로운 이야기 시작하기" onPress={newRoom}/></View>
</>:<>
<View style={s.header}><Pressable accessibilityLabel="목록으로" onPress={()=>{setPhoto(null);setScreen('list')}}><Text style={s.title}>‹</Text></Pressable><View style={{flex:1,marginLeft:16}}><Text style={s.heading}>{room?.partner.name}</Text><Text style={s.small}>{room?.partner.relation} {room?.partner.date?'· 연락 '+elapsed(room.partner.date)+'일째':''}</Text></View><Pressable accessibilityLabel="상담 삭제" onPress={()=>Alert.alert('상담 삭제','이 기기의 상담 기록을 삭제할까?',[{text:'취소'},{text:'삭제',style:'destructive',onPress:()=>{setRooms(rs=>rs.filter(r=>r.id!==active));setScreen('list')}}])}><Text>⋯</Text></Pressable></View>
<ScrollView ref={scroll} onContentSizeChange={()=>scroll.current?.scrollToEnd()} contentContainerStyle={{padding:20}}>
<Text style={[s.centerSmall,{marginBottom:24}]}>세 메이트가 함께 듣고 있어 · 예시 응답</Text>
{room?.messages.map(m=><View key={m.id} style={{alignItems:m.user?'flex-end':'flex-start',marginBottom:22}}>{!m.user&&<Text style={s.small}>{mates[m.mate].name} · {mates[m.mate].type}</Text>}<View style={[s.bubble,{backgroundColor:m.user?'#CA554B':mates[m.mate].color}]}>{m.image&&<Image source={{uri:m.image}} style={{width:200,height:220,borderRadius:12}}/>}{!!m.text&&<Text style={{color:m.user?'white':'#454048',lineHeight:23}}>{m.text}</Text>}</View></View>)}
<Button title="최근 대화 사진 올리기" light onPress={pick}/>
</ScrollView>
{photo&&<View style={s.header}><Image source={{uri:photo}} style={{width:48,height:48}}/><Pressable onPress={()=>setPhoto(null)}><Text>첨부 취소 ×</Text></Pressable></View>}
<View style={s.composer}><Pressable accessibilityLabel="사진 첨부" onPress={pick}><Text style={s.title}>＋</Text></Pressable><TextInput accessibilityLabel="메시지" style={[s.input,{flex:1,marginHorizontal:10,maxHeight:100}]} placeholder="무슨 생각이 들었어?" multiline value={text} onChangeText={setText}/><Button title="↑" onPress={send}/></View>
</>}
<Modal visible={!!form} transparent animationType="fade" onRequestClose={()=>setForm(null)}><View style={s.overlay}><ScrollView style={s.modal} keyboardShouldPersistTaps="handled">{form&&<>
<View style={s.row}><Text style={[s.heading,{flex:1}]}>누구의 마음이 궁금해?</Text><Pressable accessibilityLabel="팝업 닫기" onPress={()=>setForm(null)}><Text>×</Text></Pressable></View><Text style={s.small}>우리에게 상대를 소개해 줘.</Text>
{[['name','이름','이름 또는 닉네임'],['age','나이','만 나이'],['mbti','MBTI','모르면 비워 둬도 괜찮아'],['date','연락 시작일','YYYY-MM-DD']].map(([key,label,hint])=><View key={key}><Text style={s.label}>{label}</Text><TextInput accessibilityLabel={label} style={s.input} placeholder={hint} value={form[key]} maxLength={key==='mbti'?4:undefined} keyboardType={key==='age'?'number-pad':'default'} onChangeText={v=>setForm({...form,[key]:key==='mbti'?v.toUpperCase():v})}/></View>)}
<Button title="📅 캘린더에서 연락 시작일 선택" light onPress={()=>setCalendar(true)}/><Calendar visible={calendar} value={form.date} onChange={date=>setForm({...form,date})} onClose={()=>setCalendar(false)}/><Text style={s.label}>성별</Text><View style={s.choices}>{['선택 안 함','남성','여성','기타'].map(v=><Pressable key={v} style={[s.chip,form.gender===v&&s.selected]} onPress={()=>setForm({...form,gender:v})}><Text>{v}</Text></Pressable>)}</View>
<Text style={s.label}>관계</Text><View style={s.choices}>{relations.map(v=><Pressable key={v} style={[s.chip,form.relation===v&&s.selected]} onPress={()=>setForm({...form,relation:v})}><Text>{v}</Text></Pressable>)}</View>
{!!form.date&&!validate({...form,name:'x'})&&<Text style={s.accent}>연락 시작한 지 {elapsed(form.date)}일</Text>}<Text style={s.error}>{error}</Text><Button title="확인" onPress={save}/><Text style={[s.small,{marginVertical:16}]}>이름은 닉네임으로 입력해도 괜찮아.</Text>
</>}</ScrollView></View></Modal>
<Modal visible={notify} transparent onRequestClose={()=>setNotify(false)}><View style={s.overlay}><View style={s.modal}><Text style={s.title}>20:41</Text><Text style={s.small}>후속 푸시 예시 · 실제 발송 없음</Text>{mates.filter((_,i)=>i!==1).map((m,i)=><Pressable key={m.name} style={[s.card,{marginTop:16}]} onPress={()=>{setNotify(false);if(rooms[0]){setActive(rooms[0].id);setScreen('chat')}else{setScreen('list');newRoom()}}}><Text style={s.heading}>♡ SomeMate · {m.name}</Text><Text>{i===0?'그래서 다음은 어떻게 됐어?':'그래서 화해 완료 된 거니?'}</Text></Pressable>)}<Button title="닫기" onPress={()=>setNotify(false)}/></View></View></Modal>
</KeyboardAvoidingView>
}
const s=StyleSheet.create({
root:{flex:1,backgroundColor:'#FFFCF9',paddingTop:Platform.OS==='ios'?55:30,paddingBottom:Platform.OS==='ios'?22:10},top:{flexDirection:'row',justifyContent:'space-between',paddingHorizontal:20,paddingBottom:12},login:{padding:28},logo:{fontSize:38,fontWeight:'800',color:'#CA554B',textAlign:'center',marginTop:20},small:{fontSize:12,color:'#91898B',lineHeight:20},centerSmall:{fontSize:12,color:'#91898B',lineHeight:20,textAlign:'center'},heading:{fontSize:17,fontWeight:'700',color:'#353138',marginVertical:6},title:{fontSize:26,fontWeight:'700',color:'#353138'},input:{borderWidth:1,borderColor:'#EDE7E3',backgroundColor:'#FFFDFC',borderRadius:14,padding:14,marginVertical:5,color:'#353138'},button:{backgroundColor:'#CA554B',padding:16,borderRadius:14,alignItems:'center',marginVertical:8},light:{backgroundColor:'#F8E9E3'},row:{flexDirection:'row',alignItems:'center'},spread:{flexDirection:'row',justifyContent:'space-around',alignItems:'center',marginVertical:18,gap:8},header:{padding:20,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},subtitle:{paddingHorizontal:20,fontSize:12,color:'#91898B'},card:{backgroundColor:'#FBEDE7',padding:20,borderRadius:22,marginBottom:14},empty:{alignItems:'center',paddingTop:30,gap:15},footer:{padding:20},bubble:{padding:16,borderRadius:18,maxWidth:'90%'},composer:{flexDirection:'row',alignItems:'center',paddingHorizontal:16,borderTopWidth:1,borderColor:'#EDE7E3'},overlay:{flex:1,backgroundColor:'#0005',justifyContent:'center',padding:22},modal:{backgroundColor:'#FFFDFC',borderRadius:28,padding:22,maxHeight:'88%'},label:{fontSize:12,fontWeight:'600',color:'#615B60',marginTop:10},choices:{flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:8},chip:{padding:12,backgroundColor:'#F5F1EE',borderRadius:12},selected:{backgroundColor:'#F6D8D0'},accent:{color:'#CA554B',marginTop:12},error:{color:'#B03930',fontSize:12,marginVertical:10}
});


