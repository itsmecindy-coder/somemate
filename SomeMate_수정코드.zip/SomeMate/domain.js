export const mates=[
{name:'김원일',type:'긍정형',color:'#FCEDE5',intro:'안녕 난 김원일이라고 해. 지금 상황에서 좋은 신호를 찾아보면서 긍정회로를 돌려볼게!'},
{name:'한지효',type:'염세적',color:'#F0EAF9',intro:'난 한지효야. 기대만으로 상처받지 않게, 걱정되는 부분도 솔직하게 짚어볼게.'},
{name:'서윤지',type:'신중형',color:'#E9F4EE',intro:'안녕, 난 서윤지야. 앞뒤 맥락을 같이 보면서 천천히 생각해보자.'}
];
export const relations=['썸타는 사이','연인'];
export const empty={name:'',age:'',gender:'선택 안 함',relation:'썸타는 사이',mbti:'',date:''};
export function elapsed(date){if(!date)return '';let n=new Date();n.setHours(0,0,0,0);return Math.round((n-new Date(date+'T00:00:00'))/86400000)+1;}
export function validate(p){
if(!p.name.trim())return '이름 또는 닉네임을 입력해 줘.';
if(p.age&&(!/^\d+$/.test(p.age)||+p.age<1||+p.age>120))return '나이를 1~120 사이로 입력해 줘.';
if(!relations.includes(p.relation))return '관계를 선택해 줘.';
if(p.mbti&&!/^[EI][NS][TF][JP]$/.test(p.mbti))return 'MBTI 네 글자를 확인해 줘. 모르면 비워 둬도 괜찮아.';
if(p.date){const d=new Date(p.date+'T00:00:00');const parts=p.date.split('-').map(Number);if(!/^\d{4}-\d{2}-\d{2}$/.test(p.date)||!Number.isFinite(+d)||d.getFullYear()!==parts[0]||d.getMonth()+1!==parts[1]||d.getDate()!==parts[2]||d>new Date())return '오늘 이전의 올바른 날짜를 선택해 줘.';}
return '';
}
export function greeting(){return mates.map((m,i)=>({id:'intro-'+i,mate:i,text:m.intro}));}
export function demoReplies(){return ['좋은 가능성도 같이 찾아보자. 실제 대화 분석 AI는 아직 연결 전이라 이건 예시 답변이야.','기대만으로 결론을 내리지는 말자. 상대가 말과 행동을 꾸준히 이어가는지도 봐야 해. 이건 UI 예시야.','앞뒤 상황과 평소 연락 방식도 알려줄래? 캡처 내용을 읽는 기능은 아직 연결하지 않았어.'].map((text,i)=>({id:Date.now()+'-'+i,mate:i,text}));}

