import React,{useState} from 'react';
import {View,Text,Modal,Pressable,StyleSheet} from 'react-native';
export default function Calendar({visible,value,onChange,onClose}){
const initial=value?new Date(value+'T00:00:00'):new Date();
const [month,setMonth]=useState(new Date(initial.getFullYear(),initial.getMonth(),1));
const year=month.getFullYear(),m=month.getMonth(),offset=new Date(year,m,1).getDay(),count=new Date(year,m+1,0).getDate();
const dateString=d=>year+'-'+String(m+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
const today=new Date();today.setHours(0,0,0,0);
return <Modal visible={visible} transparent onRequestClose={onClose}><View style={s.overlay}><View style={s.box}>
<View style={s.row}><Text style={s.title}>연락을 시작한 날</Text><Pressable onPress={onClose}><Text>×</Text></Pressable></View>
<View style={s.row}><Pressable accessibilityLabel="이전 달" onPress={()=>setMonth(new Date(year,m-1,1))}><Text>‹</Text></Pressable><Text style={s.title}>{year}년 {m+1}월</Text><Pressable accessibilityLabel="다음 달" onPress={()=>setMonth(new Date(year,m+1,1))}><Text>›</Text></Pressable></View>
<View style={s.grid}>{['일','월','화','수','목','금','토'].map(x=><Text key={x} style={s.day}>{x}</Text>)}{Array.from({length:offset},(_,i)=><View key={'blank'+i} style={s.cell}/>)}{Array.from({length:count},(_,i)=>i+1).map(d=>{const future=new Date(year,m,d)>today,selected=value===dateString(d);return <Pressable key={d} disabled={future} accessibilityLabel={dateString(d)} style={[s.cell,selected&&s.selected]} onPress={()=>{onChange(dateString(d));onClose()}}><Text style={{color:future?'#D8D3D0':selected?'white':'#51484D'}}>{d}</Text></Pressable>})}</View>
</View></View></Modal>
}
const s=StyleSheet.create({overlay:{flex:1,backgroundColor:'#0005',justifyContent:'center',padding:30},box:{backgroundColor:'white',padding:20,borderRadius:24},row:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:22},title:{fontSize:16,fontWeight:'700'},grid:{flexDirection:'row',flexWrap:'wrap'},day:{width:'14.2857%',textAlign:'center',fontSize:11,color:'#93898A',marginBottom:12},cell:{width:'14.2857%',height:39,alignItems:'center',justifyContent:'center',borderRadius:22},selected:{backgroundColor:'#CA554B'}});

